def sum_a_b():
    return a + b

result = sum_a_b(2,3)
print(result)